package aadd;

public enum Rol {

	ADMINISTRADOR, USUARIO, OPERADOR;
}
