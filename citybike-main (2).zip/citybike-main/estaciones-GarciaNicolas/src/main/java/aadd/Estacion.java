package aadd;

import java.time.LocalDate;
import java.util.List;

public class Estacion {

	private String Nombre;
    private LocalDate fechaAlta;
    private int maxBicicletas;
    private String direccion;
    private double latitud;
    private double longitud;
    private List<String> sitiosTuristicos;
     
    // Getters and setters
    
	public String getNombre() {
		return Nombre;
	}
	public void setNombre(String nombre) {
		Nombre = nombre;
	}
	public LocalDate getFechaAlta() {
		return fechaAlta;
	}
	public void setFechaAlta(LocalDate fechaAlta) {
		this.fechaAlta = fechaAlta;
	}
	public int getMaxBicicletas() {
		return maxBicicletas;
	}
	public void setMaxBicicletas(int maxBicicletas) {
		this.maxBicicletas = maxBicicletas;
	}
	public String getDireccion() {
		return direccion;
	}
	public void setDireccion(String direccion) {
		this.direccion = direccion;
	}
	public double getLatitud() {
		return latitud;
	}
	public void setLatitud(double latitud) {
		this.latitud = latitud;
	}
	public double getLongitud() {
		return longitud;
	}
	public void setLongitud(double longitud) {
		this.longitud = longitud;
	}
	public List<String> getSitioTuristico() {
		return sitiosTuristicos;
	}
	public void setSitioTuristico(List<String> touristInfo) {
		this.sitiosTuristicos = touristInfo;
	}
    
    
}
