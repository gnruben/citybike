package repositorio;

public interface Identificable {

	String getId();
	
	void setId(String id);
}
