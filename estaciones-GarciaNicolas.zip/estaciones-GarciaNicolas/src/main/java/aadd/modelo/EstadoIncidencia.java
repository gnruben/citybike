package aadd.modelo;

public enum EstadoIncidencia {
	PENDIENTE,ASIGNADA, RESUELTA, CANCELADA
}
