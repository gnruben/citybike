package aadd.servicios;

import java.time.LocalDate;
import java.util.List;
import java.util.UUID;

import aadd.modelo.Bicicleta;
import aadd.modelo.EstadoIncidencia;
import aadd.modelo.Incidencia;
import aadd.repositorio.RepositorioBicicletaAdHocJPA;
import repositorio.EntidadNoEncontrada;
import repositorio.FactoriaRepositorios;
import repositorio.Repositorio;
import repositorio.RepositorioException;
import servicio.FactoriaServicios;

public class ServicioIncidencias implements IServicioIncidencias {

	private Repositorio<Bicicleta, String> repositorioBicicleta = FactoriaRepositorios.getRepositorio(Bicicleta.class);
	private IServicioEstaciones servicioEstaciones = FactoriaServicios.getServicio(IServicioEstaciones.class);

	/**
	 * Crear una incidencia en una bicicleta. Esta operación recibe el identificador
	 * de la bicicleta y una descripción de la incidencia. La incidencia se crea con
	 * estado pendiente y la aplicación establece su fecha de creación y un código
	 * identificador. La bici se considera no disponible.
	 * 
	 * @param idBicicleta: Identificador de la Bicicleta.
	 * @param descripcion: Descripción de la Incidencia.
	 * @throws ServicioIncidenciasException
	 */
	@Override
	public String crearIncidencia(String idBicicleta, String descripcion) throws ServicioIncidenciasException {
		if (idBicicleta == null || idBicicleta.isEmpty())
			throw new IllegalArgumentException(
					"El id de la bicicleta, que se quiere asignarle una incidencia, no puede ser nulo ni vacío");
		if (descripcion == null || descripcion.isEmpty())
			throw new IllegalArgumentException(
					"Tiene que haber una descripción de la incidencia que se ha detectado en la bicicleta");

		String id = null;
		try {
			Bicicleta bicicleta = repositorioBicicleta.getById(idBicicleta);
			if (bicicleta != null) {
				Incidencia incidencia = new Incidencia();
				incidencia.setId(UUID.randomUUID().toString()); // ID
				incidencia.setBicicleta(bicicleta);
				incidencia.setDescripcion(descripcion);
				incidencia.setFechaInicio(LocalDate.now());
				incidencia.setEstado(EstadoIncidencia.PENDIENTE);
				bicicleta.addIncidencia(incidencia);

				repositorioBicicleta.update(bicicleta); // TODO
				bicicleta.setDisponible(false);
				id = incidencia.getId();
			}

		} catch (EntidadNoEncontrada e) {
			throw new ServicioIncidenciasException("Bicicleta no encontrada con ID: " + idBicicleta);
		} catch (RepositorioException e) {
			throw new ServicioIncidenciasException("Error en el repositorio: " + e.getStackTrace());
		}

		return id;
	}

	@Override
	public void cancelarIncidencia(Incidencia incidencia, String motivoCierre) throws ServicioIncidenciasException {
		
		if (incidencia == null  )
			throw new IllegalArgumentException("Debe introducir incidencia que se quiere cancelar.");
		if (motivoCierre == null || motivoCierre.isEmpty())
			throw new IllegalArgumentException("Tiene que haber un motivo de cierre de la incidencia que se quiere cancelar.");
		
		if (incidencia.getEstado() != EstadoIncidencia.PENDIENTE)
			throw new ServicioIncidenciasException("El estado de la incidencia no es PENDIENTE no se puede cancelar");
		
		incidencia.setEstado(EstadoIncidencia.CANCELADA);
		incidencia.setFechaFin(LocalDate.now());
		incidencia.setMotivoCierre(motivoCierre);

		incidencia.getBicicleta().setDisponible(true);
		Bicicleta bici = incidencia.getBicicleta();
		
		try {
			repositorioBicicleta.update(bici);
		} catch (RepositorioException e) {
			throw new ServicioIncidenciasException("Error en el repositorio de bicis");
		} catch (EntidadNoEncontrada e) {
			throw new ServicioIncidenciasException("No se encontró la bici");
		}
	}

	@Override
	public void asignarIncidencia(Incidencia incidencia, String idOperarioAsignado) throws ServicioIncidenciasException {
		if (incidencia == null  )
			throw new IllegalArgumentException("Debe introducir incidencia que se le quiere asignar un operario.");
		if (idOperarioAsignado == null || idOperarioAsignado.isEmpty())
			throw new IllegalArgumentException("El id del Operario, al que le ha sido asignada esta incidencia, no puede ser nulo.");
		
		if (incidencia.getEstado() != EstadoIncidencia.PENDIENTE)
			throw new ServicioIncidenciasException("El estado de la incidencia no es PENDIENTE no se puede asignar");
		
		incidencia.setEstado(EstadoIncidencia.ASIGNADA);
		incidencia.setIdOperarioAsignado(idOperarioAsignado);
		
		try {
			repositorioBicicleta.update(incidencia.getBicicleta());
			servicioEstaciones.retirarBicicleta(incidencia.getBicicleta().getId());
			
		} catch (ServicioEstacionesException  e) {
			throw new ServicioIncidenciasException("Error en el servicio de estaciones");
		} catch (RepositorioException e) {
			throw new ServicioIncidenciasException("Error en el repositorio");
		} catch (EntidadNoEncontrada e) {
			throw new ServicioIncidenciasException("Error no se encontró la bici vinculada a la incidencia: "+incidencia.getBicicleta().getId());
		}
	}

	@Override
	public void resolverIncidencia(Incidencia incidencia, String motivoCierre, boolean isReparada) throws ServicioIncidenciasException {
		if (incidencia == null  )
			throw new IllegalArgumentException("Debe introducir incidencia que se quiere resolver.");
		if (motivoCierre == null || motivoCierre.isEmpty())
			throw new IllegalArgumentException("Tiene que haber un motivo de cierre de la incidencia que se quiere resolver.");
		if (isReparada != false && isReparada != true    )
			throw new IllegalArgumentException("Debe indicar si la bicicleta ha sido reparada o no.");
		
		if (incidencia.getEstado() != EstadoIncidencia.ASIGNADA)
			throw new ServicioIncidenciasException("El estado de la incidencia no es ASIGNADA no se puede resolver");
		
		incidencia.setEstado(EstadoIncidencia.RESUELTA);
		incidencia.setFechaFin(LocalDate.now());
		incidencia.setMotivoCierre(motivoCierre);
		
		try {
			if (isReparada) 
				servicioEstaciones.estacionarBicicleta(incidencia.getBicicleta().getId());	
			else
				servicioEstaciones.darBajaBicicleta(incidencia.getBicicleta().getId(),motivoCierre);
		} catch (ServicioEstacionesException e) {
			e.printStackTrace();
		}
	}

	
	/**
	 * Recuperar incidencias abiertas. Esta operación devolverá un listado de
	 * incidencias que no hayan sido cerradas.
	 */
	@Override
	public List<Incidencia> getIncidenciasAbiertas() {
		return ((RepositorioBicicletaAdHocJPA) repositorioBicicleta).getIncidenciasPendientes();
	}

}
