package aadd;

public class Test {
	private String id;

}
